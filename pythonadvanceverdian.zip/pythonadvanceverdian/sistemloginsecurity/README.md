# Studi Kasus 3: Sistem Keamanan Akun & Audit Log

## Deskripsi
Program ini merupakan simulasi sistem keamanan akun dan pencatatan aktivitas login menggunakan Python. Program melakukan validasi username dan password menggunakan Regular Expression (RegEx). Setiap percobaan login dicatat melalui audit log yang menampilkan waktu, username, status login, dan alasan penolakan apabila login gagal.

Program menggunakan class `User` untuk mengelola data akun, property untuk memvalidasi username dan password, serta decorator untuk mencatat hasil proses login.

## Tujuan
Memahami penerapan validasi username dan password menggunakan RegEx.
Menerapkan konsep Object-Oriented Programming (OOP) menggunakan class dan object.
Memahami penggunaan `@property` dan setter dalam validasi atribut.
Menggunakan decorator untuk menambahkan fungsi audit log.
Mencatat waktu dan status setiap percobaan login.
Menguji berbagai kondisi login, baik yang ditolak maupun yang berhasil.

## Fitur Program
1. Validasi username dengan panjang minimal 5 karakter.
2. Validasi password dengan panjang minimal 8 karakter dan harus mengandung setidaknya satu angka.
3. Pengelolaan data pengguna menggunakan class `User`.
4. Pencatatan aktivitas login menggunakan decorator `audit_log`.
5. Pencatatan waktu menggunakan modul `datetime`.
6. Penanganan kesalahan validasi menggunakan `try-except`.
7. Pengujian empat skenario login yang berbeda.

## Ketentuan Validasi

### 1. Username
Username harus memenuhi ketentuan berikut:
Berupa string.
Memiliki minimal 5 karakter.
Hanya boleh berisi huruf dan angka.

Contoh username yang valid: `Hamdan123`.

Contoh username yang tidak valid: `Ham!`, karena mengandung karakter khusus.

### 2. Password
Password harus memenuhi ketentuan berikut:
Berupa string.
Memiliki minimal 8 karakter.
Mengandung setidaknya satu angka.

Contoh password yang valid: `aman12345`.

Contoh password yang tidak valid: `abc12`, karena terlalu pendek, dan `passwordaman`, karena tidak mengandung angka.

## Konsep Python yang Digunakan

1. **Regular Expression (`re`)** — memeriksa format username dan password menggunakan pola tertentu.
2. **Class dan Object** — class `User` digunakan untuk menyimpan serta mengelola data akun.
3. **Constructor (`__init__`)** — menginisialisasi username dan password saat object dibuat.
4. **Property (`@property`)** — menyediakan akses ke atribut username dan password.
5. **Setter** — memvalidasi nilai username dan password sebelum disimpan.
6. **Decorator (`@audit_log`)** — menambahkan pencatatan aktivitas pada fungsi login.
7. **`functools.wraps`** — mempertahankan metadata fungsi asli ketika menggunakan decorator.
8. **Modul `datetime`** — mencatat waktu setiap percobaan login.
9. **Exception Handling (`try-except`)** — menangani kesalahan validasi dan mencatat alasan login ditolak.
10. **Fungsi dan Percabangan** — memeriksa kesesuaian kredensial dan menentukan hasil login.

## Skenario Pengujian

Program menjalankan empat skenario pengujian berikut:

| No. | Skenario | Hasil yang Diharapkan |
|---|---|---|
| 1 | Username `Ham!` tidak valid | Login ditolak karena format username tidak valid. |
| 2 | Password `abc12` terlalu pendek | Login ditolak karena password tidak memenuhi ketentuan. |
| 3 | Password `passwordaman` tanpa angka | Login ditolak karena password tidak mengandung angka. |
| 4 | Username dan password benar | Login berhasil. |

## Cara Menjalankan Program

Pastikan Python sudah terpasang di komputer. Simpan kode program dengan nama `main.py`, kemudian buka terminal pada folder tempat file tersebut disimpan.

Jalankan perintah berikut:

```bash
python main.py
```

Jika menggunakan macOS atau Linux dan perintah `python` tidak tersedia, gunakan:

```bash
python3 main.py
```

Program tidak memerlukan instalasi library tambahan karena menggunakan modul bawaan Python.

## Hasil yang Diharapkan

Program menampilkan judul sistem keamanan akun, empat skenario pengujian, dan catatan audit untuk setiap percobaan login.

Contoh format output audit log:

```text
[WAKTU] User: Ham! | Status: DITOLAK | Alasan: Format username tidak valid.
[WAKTU] User: Hamdan123 | Status: DITOLAK | Alasan: Password minimal 8 karakter dan harus mengandung angka.
[WAKTU] User: Hamdan123 | Status: DITOLAK | Alasan: Password minimal 8 karakter dan harus mengandung angka.
[WAKTU] User: Hamdan123 | Status: BERHASIL
```

Keterangan `WAKTU` pada contoh tersebut merupakan placeholder. Program akan menampilkan tanggal dan waktu aktual saat percobaan login dilakukan.

## Screenshot Output

Tambahkan screenshot hasil eksekusi program pada bagian ini sebagai bukti bahwa program telah berhasil dijalankan. Pastikan keempat skenario pengujian dan hasil audit log terlihat dengan jelas.

## Kesimpulan

Program ini menunjukkan penerapan validasi akun dan pencatatan aktivitas login menggunakan Python. RegEx digunakan untuk memeriksa format username dan password, sedangkan class dan property membantu mengelola data akun. Decorator `audit_log` digunakan untuk mencatat waktu, status, dan alasan kegagalan login. Dengan demikian, program dapat membedakan percobaan login yang berhasil dan yang ditolak berdasarkan ketentuan validasi yang telah ditetapkan.