# Python Advanced Topics

Repository ini berisi implementasi tiga studi kasus Python yang membahas pengolahan data mahasiswa, simulasi streaming data sensor IoT, serta sistem keamanan akun dan audit log. Setiap studi kasus dibuat untuk menerapkan konsep-konsep Python melalui program sederhana yang dapat dijalankan dan diuji secara langsung.

## Identitas Mahasiswa

| Keterangan | Informasi |
|---|---|
| Nama | Verdian Akbar Pradana |
| NIM | 2595114033 |
| Program Studi | Teknik Informatika |
| Kelas | B |

## Daftar Studi Kasus

### 1. Analisis Nilai Mahasiswa

Program ini digunakan untuk mengolah nilai mahasiswa, menghitung nilai akhir berdasarkan bobot penilaian, mengurutkan peringkat, menampilkan mahasiswa berprestasi, dan menentukan mahasiswa terbaik.

**Fitur Program:**
- Menghitung nilai akhir dengan bobot tugas 30%, UTS 30%, dan UAS 40%.
- Mengurutkan mahasiswa berdasarkan nilai akhir tertinggi.
- Menampilkan mahasiswa dengan nilai akhir di atas 80.
- Menentukan mahasiswa dengan nilai tertinggi.

**Konsep Python yang Digunakan:**
- List dan dictionary.
- List comprehension.
- Dictionary unpacking.
- Fungsi `sorted()` dan `lambda`.
- Fungsi `enumerate()`.
- Filtering dan pengurutan data.

**Cara Menjalankan:**

```bash
python3 case-01-analisis-nilai/analisis_nilai.py
```

**Screenshot Output:**

![Output Analisis Nilai Mahasiswa](case-01-analisis-nilai/output.png)

---

### 2. Streaming Data Sensor IoT

Program ini mensimulasikan monitoring suhu sensor IoT dengan menghasilkan data suhu secara bertahap menggunakan generator. Setiap data kemudian dikelompokkan berdasarkan kategori suhu.

**Fitur Program:**
- Menghasilkan 10 data suhu secara bertahap.
- Mengategorikan suhu menjadi Dingin, Normal, dan Panas.
- Menampilkan nomor pembacaan, suhu, dan kategori dalam bentuk tabel.
- Memproses data menggunakan generator.

**Ketentuan Kategori Suhu:**

| Rentang Suhu | Kategori |
|---|---|
| Di bawah 20°C | Dingin |
| 20°C sampai 30°C | Normal |
| Di atas 30°C | Panas |

**Konsep Python yang Digunakan:**
- Generator dan keyword `yield`.
- Fungsi.
- Percabangan `if`, `elif`, dan `else`.
- Perulangan `for`.
- Fungsi `enumerate()`.
- Formatted string (`f-string`).

**Cara Menjalankan:**

```bash
python3 case-02-sensor-iot/data_sensor_iot.py
```

**Screenshot Output:**

![Output Streaming Data Sensor IoT](case-02-sensor-iot/output.png)

---

### 3. Sistem Keamanan Akun & Audit Log

Program ini merupakan simulasi sistem keamanan akun yang melakukan validasi username dan password menggunakan Regular Expression (RegEx). Program juga mencatat hasil percobaan login melalui audit log yang menampilkan waktu, username, status, dan alasan penolakan.

**Fitur Program:**
Memvalidasi username minimal 5 karakter dan hanya menggunakan huruf atau angka.
Memvalidasi password minimal 8 karakter dan mengandung setidaknya satu angka.
Memeriksa kesesuaian username dan password.
Mencatat waktu serta hasil setiap percobaan login.
Menguji skenario login yang berhasil maupun ditolak.

**Konsep Python yang Digunakan:**
Regular Expression (`re`).
Class dan object.
Constructor `__init__()`.
Property dan setter.
Decorator.
Modul `datetime`.
Exception handling (`try-except`).
`functools.wraps`.

**Cara Menjalankan:**

```bash
python3 case-03-login-security/login_security.py
```

**Screenshot Output:**

![Output Sistem Keamanan Akun dan Audit Log](case-03-login-security/output.png)

---

## Struktur Folder Proyek

```text
Python-Advanced-Topics/
├── README.md
├── case-01-analisis-nilai/
│   ├── analisis_nilai.py
│   ├── README.md
│   └── output.png
├── case-02-sensor-iot/
│   ├── data_sensor_iot.py
│   ├── README.md
│   └── output.png
└── case-03-login-security/
    ├── login_security.py
    ├── README.md
    └── output.png
```

Struktur tersebut merupakan contoh susunan repository. Pastikan nama file dan folder sesuai dengan yang digunakan pada proyek sebenarnya.

## Persyaratan

- Python 3.
- Visual Studio Code atau editor kode lainnya.
- Terminal untuk menjalankan program.
- Git dan akun GitHub untuk mengunggah proyek.

Ketiga program menggunakan modul bawaan Python sehingga tidak memerlukan instalasi library tambahan.

## Cara Menjalankan Proyek

1. Clone atau unduh repository ke komputer.
2. Buka folder `Python-Advanced-Topics` di Visual Studio Code.
3. Buka terminal melalui menu **Terminal → New Terminal**.
4. Jalankan file Python sesuai studi kasus yang ingin diuji.

Contoh menjalankan Studi Kasus 1:

```bash
python3 case-01-analisis-nilai/analisis_nilai.py
```

Contoh menjalankan Studi Kasus 2:

```bash
python3 case-02-sensor-iot/data_sensor_iot.py
```

Contoh menjalankan Studi Kasus 3:

```bash
python3 case-03-login-security/login_security.py
```

## Progres Pengerjaan

[x] Studi Kasus 1: Analisis Nilai Mahasiswa
[x] Studi Kasus 2: Streaming Data Sensor IoT
[x] Studi Kasus 3: Sistem Keamanan Akun & Audit Log
[x] Dokumentasi README setiap studi kasus
[ ] Pemeriksaan akhir file dan screenshot
[ ] Upload dan verifikasi seluruh file di GitHub

## Kesimpulan

Ketiga studi kasus ini menunjukkan penerapan berbagai konsep Python dalam menyelesaikan permasalahan yang berbeda. Studi Kasus 1 berfokus pada pengolahan dan analisis data, Studi Kasus 2 membahas penggunaan generator untuk memproses data sensor secara bertahap, sedangkan Studi Kasus 3 menerapkan validasi akun dan pencatatan aktivitas login.

Melalui proyek ini, konsep Python dapat dipelajari dan diterapkan secara langsung melalui program yang terstruktur, mudah dijalankan, dan dilengkapi dokumentasi.
