# Studi Kasus 2: Streaming Data Sensor IoT

## Deskripsi
Program ini merupakan simulasi monitoring suhu sensor IoT menggunakan Python. Program menghasilkan data suhu secara bertahap menggunakan generator, kemudian menentukan kategori suhu berdasarkan nilai yang dihasilkan. Hasil pembacaan suhu ditampilkan dalam bentuk tabel yang berisi nomor, suhu, dan kategori.

## Tujuan
Memahami penggunaan generator dalam Python.
Menghasilkan data secara bertahap menggunakan `yield`.
Mengelompokkan suhu berdasarkan kondisi tertentu.
Menampilkan data sensor dalam format tabel yang rapi.

## Fitur Program
1. Menghasilkan 10 data suhu sensor secara bertahap.
2. Menentukan kategori suhu menjadi Dingin, Normal, atau Panas.
3. Menggunakan generator agar data dapat diproses satu per satu.
4. Menampilkan nomor pembacaan, nilai suhu, dan kategori suhu.

## Ketentuan Kategori Suhu
Program menggunakan ketentuan berikut:

| Rentang Suhu | Kategori |
|---|---|
| Di bawah 20°C | Dingin |
| 20°C sampai 30°C | Normal |
| Di atas 30°C | Panas |

## Konsep Python yang Digunakan
1. **Generator** — fungsi `sensor_suhu()` menghasilkan data suhu secara bertahap.
2. **Keyword `yield`** — mengembalikan satu nilai suhu pada setiap proses iterasi.
3. **Fungsi** — `kategori_suhu()` menentukan kategori berdasarkan nilai suhu.
4. **Percabangan `if`, `elif`, dan `else`** — mengelompokkan suhu sesuai rentang yang ditentukan.
5. **Perulangan `for`** — membaca data generator satu per satu.
6. **Fungsi `enumerate()`** — memberikan nomor urut pada setiap pembacaan suhu.
7. **Formatted String (`f-string`)** — menyusun tampilan tabel agar lebih mudah dibaca.
8. **Main Guard** — `if __name__ == "__main__":` memastikan fungsi `main()` dijalankan ketika file dieksekusi secara langsung.

## Data Suhu
Data suhu yang digunakan dalam simulasi adalah:

`16.5, 18.0, 19.5, 21.0, 23.5, 25.0, 28.5, 30.0, 32.5, 36.0`

Data tersebut diproses secara berurutan menggunakan generator.

## Cara Menjalankan Program
Pastikan Python sudah terpasang di komputer. Simpan kode program dengan nama `main.py`, kemudian buka terminal pada folder tempat file disimpan dan jalankan perintah berikut:

```bash
python main.py
```

Jika menggunakan macOS atau Linux dan perintah `python` tidak tersedia, gunakan:

```bash
python3 main.py
```

## Hasil yang Diharapkan
Program menampilkan tabel monitoring suhu yang berisi nomor pembacaan, suhu dalam derajat Celsius, dan kategori suhu.

Contoh output:

```text
==================================================
       MONITORING SUHU SENSOR IoT
==================================================
No.  Suhu           Kategori
--------------------------------------------------
1    16.5           Dingin
2    18.0           Dingin
3    19.5           Dingin
4    21.0           Normal
5    23.5           Normal
6    25.0           Normal
7    28.5           Normal
8    30.0           Normal
9    32.5           Panas
10   36.0           Panas
```

## Kesimpulan
Program ini menunjukkan penerapan generator untuk menghasilkan dan memproses data suhu secara bertahap. Setiap nilai suhu dikategorikan menggunakan percabangan, kemudian ditampilkan dalam tabel. Dengan cara ini, simulasi monitoring suhu sensor IoT dapat dilakukan secara sederhana dan terstruktur menggunakan Python.