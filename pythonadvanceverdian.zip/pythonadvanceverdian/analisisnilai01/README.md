# Studi Kasus 1: Analisis Nilai Mahasiswa

## Deskripsi
Program ini digunakan untuk mengolah dan menganalisis nilai mahasiswa menggunakan Python. Data yang diolah meliputi nama, NIM, nilai tugas, UTS, dan UAS. Program menghitung nilai akhir berdasarkan bobot yang telah ditentukan, mengurutkan mahasiswa berdasarkan peringkat, menampilkan mahasiswa berprestasi, serta menentukan mahasiswa dengan nilai tertinggi.

## Tujuan
Mengolah data mahasiswa menggunakan list dan dictionary.
Menghitung nilai akhir berdasarkan bobot penilaian.
Menerapkan list comprehension untuk mengolah data.
Mengurutkan data menggunakan fungsi `sorted()` dan `lambda`.
Menampilkan peringkat mahasiswa dan menyaring mahasiswa berprestasi.

## Ketentuan Perhitungan Nilai
Nilai akhir dihitung dengan bobot sebagai berikut:
Nilai tugas: 30%
Nilai UTS: 30%
Nilai UAS: 40%

Rumus:

`Nilai Akhir = (Tugas × 0.30) + (UTS × 0.30) + (UAS × 0.40)`

Mahasiswa dinyatakan berprestasi apabila memperoleh nilai akhir di atas 80.

## Konsep Python yang Digunakan
1. **List dan Dictionary** — menyimpan data mahasiswa beserta nilai masing-masing.
2. **List Comprehension** — menghitung nilai akhir setiap mahasiswa.
3. **Dictionary Unpacking** — menyalin data mahasiswa dan menambahkan nilai akhir.
4. **Fungsi `round()`** — membulatkan nilai akhir menjadi dua angka desimal.
5. **Fungsi `sorted()` dan `lambda`** — mengurutkan mahasiswa berdasarkan nilai akhir.
6. **Filtering** — memilih mahasiswa yang memiliki nilai akhir di atas 80.
7. **Fungsi `enumerate()`** — memberikan nomor peringkat mahasiswa.

## Cara Menjalankan Program
Pastikan Python telah terpasang di komputer. Buka terminal VS Code dari folder utama proyek, kemudian jalankan:

```bash
python case-01-analisis-nilai/main.py
```

Jika perintah `python` tidak tersedia, gunakan `python3` sesuai konfigurasi Python pada komputer.

## Hasil yang Diharapkan
Program menampilkan:
- Daftar peringkat mahasiswa dari nilai tertinggi ke terendah.
- Daftar mahasiswa berprestasi dengan nilai akhir di atas 80.
- Data mahasiswa terbaik, termasuk nama, NIM, nilai tugas, UTS, UAS, dan nilai akhir.

Berdasarkan data yang tersedia, Eka memperoleh peringkat pertama dengan nilai akhir 93.10.

## Kesimpulan
Program ini menunjukkan penerapan struktur data dan teknik pengolahan data Python untuk membantu proses analisis nilai mahasiswa secara terstruktur. Perhitungan, pengurutan, penyaringan, dan penentuan mahasiswa terbaik dilakukan secara otomatis berdasarkan data yang dimasukkan.